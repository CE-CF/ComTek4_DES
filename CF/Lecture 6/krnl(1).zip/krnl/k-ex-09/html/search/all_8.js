var searchData=
[
  ['taskprio',['TASKPRIO',['../k-ex-09_8ino.html#a9d706a3c79c31e798dc31d84d245ac57',1,'k-ex-09.ino']]]
];
