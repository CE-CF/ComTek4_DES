var searchData=
[
  ['setup',['setup',['../k-ex-09_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'k-ex-09.ino']]]
];
