var searchData=
[
  ['stksize',['STKSIZE',['../k-ex-09_8ino.html#a40e735fd3b4e60a128982c2acf74526c',1,'k-ex-09.ino']]]
];
