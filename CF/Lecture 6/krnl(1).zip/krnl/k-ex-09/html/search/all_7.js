var searchData=
[
  ['sem1',['sem1',['../k-ex-09_8ino.html#a942edf2e8891a42cbcf9f8bfdee72da6',1,'k-ex-09.ino']]],
  ['setup',['setup',['../k-ex-09_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'k-ex-09.ino']]],
  ['staka',['stakA',['../k-ex-09_8ino.html#aa63b088d2ae947bb6ca008bc5d5737c7',1,'k-ex-09.ino']]],
  ['stakb',['stakB',['../k-ex-09_8ino.html#a58ee77061f39e85850b9b178cbc17af0',1,'k-ex-09.ino']]],
  ['stakc',['stakC',['../k-ex-09_8ino.html#a5e1fc412390736833194ad4131f5f40b',1,'k-ex-09.ino']]],
  ['stksize',['STKSIZE',['../k-ex-09_8ino.html#a40e735fd3b4e60a128982c2acf74526c',1,'k-ex-09.ino']]]
];
